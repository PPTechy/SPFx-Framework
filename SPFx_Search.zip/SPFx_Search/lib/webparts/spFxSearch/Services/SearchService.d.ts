export interface ISearchResult {
    link: string;
    title: string;
    description: string;
    author: string;
}
export interface ISearchService {
    GetMockSearchResults(query: string): Promise<ISearchResult[]>;
}
export declare class MockSearchService implements ISearchService {
    GetMockSearchResults(query: string): Promise<ISearchResult[]>;
}
export declare class SearchService implements ISearchService {
    GetMockSearchResults(query: string): Promise<ISearchResult[]>;
}
//# sourceMappingURL=SearchService.d.ts.map