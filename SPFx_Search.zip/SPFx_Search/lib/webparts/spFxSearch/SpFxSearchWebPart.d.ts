import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ISpFxSearchWebPartProps {
    description: string;
}
export default class SpFxSearchWebPart extends BaseClientSideWebPart<ISpFxSearchWebPartProps> {
    constructor();
    render(): void;
    private EventListners;
    OnChangeEvent(text: HTMLElement): void;
    private renderSearchResults;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SpFxSearchWebPart.d.ts.map