declare interface ISpFxSearchWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpFxSearchWebPartStrings' {
  const strings: ISpFxSearchWebPartStrings;
  export = strings;
}
