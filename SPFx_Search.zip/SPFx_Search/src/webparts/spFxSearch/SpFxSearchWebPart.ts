
'use strict';
import { Version,Environment,EnvironmentType } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './SpFxSearchWebPart.module.scss';
import * as strings from 'SpFxSearchWebPartStrings';

import * as pnp from 'sp-pnp-js';

import * as SearchService from './Services/SearchService';
import {SPComponentLoader} from "@microsoft/sp-loader";




export interface ISpFxSearchWebPartProps
{
  description: string;
}

export default class SpFxSearchWebPart extends BaseClientSideWebPart <ISpFxSearchWebPartProps>
 {

  public constructor(){
    super();
   SPComponentLoader.loadCss("https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/1.2.0/css/fabric.min.css Jump ");
   SPComponentLoader.loadCss("https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/1.2.0/css/fabric.components.min.css Jump ");
  }


  public render(): void {
  
    this.domElement.innerHTML = `
      <div class="${styles.spFxSearch}">
        <div class="${styles.container}">
          <div class="ms-Grid-row ms-bgColor-themeLight ms-fontColor-white ${styles.row}">
            <div class="ms-Grid-col ms-u-lg10 ms-u-xl8 ms-u-xlPush2 ms-u-lgPush1">
              <div>
                <span class="ms-font-xl ms-fontColor-white">${escape(this.properties.description)}</span><br/>
               <div class="ms-Grid">
                    <div class="ms-Grid-row">
                      <div class="ms-Grid-col ms-u-sm10"><input class="ms-TextField-field" id="txtInput" placeholder="Search..." /></div>
                      <div class="ms-Grid-col ms-u-sm2"> <Button class="ms-Button ms-Button--primary" id="btnSearchQuerySubmit" type="submit" value="Submit">Search</Button></div>
                    </div>
                  </div>
                 <div class="ms-List ms-Grid-col ms-u-sm12" id="searchResultsDisplay"></div>
                </div>
            </div>
          </div>        
        </div>
      </div>`;
     this.EventListners();
    
  }


  private EventListners():void
  {
    const btnSearch = this.domElement.querySelector("#btnSearchQuerySubmit");    
    const queryText:HTMLElement = <HTMLInputElement>this.domElement.querySelector("#txtInput");
    btnSearch.addEventListener('click',() => {
         (new SpFxSearchWebPart()).OnChangeEvent(queryText);
    });
   }
    
  public OnChangeEvent(text:HTMLElement):void
  {
   (new SpFxSearchWebPart()).renderSearchResults((<HTMLInputElement>text).value)
      .then((html) =>{
        const element  = document.getElementById("searchResultsDisplay");
        element.innerHTML = html;
      });
  }


  private renderSearchResults(query:string):Promise<string>
  {
    const _search:SearchService.ISearchService = Environment.type == EnvironmentType.SharePoint ? new SearchService.SearchService() : new SearchService.MockSearchService();
    let resultsHtml:string = '';
    
    return new Promise<string>((resolve) => {
      if(query){
         _search.   
         GetMockSearchResults(query)
         .then((results) => {
             results.forEach((result) => {
                 resultsHtml += `<div class=""ms-ListItem ms-Grid-col ms-u-sm8">
                                  <a href="${result.link}"><span class="ms-ListItem-primaryText" >${result.title}</span></a>
                                   <span class="ms-ListItem-secondaryText">${result.author}<span>
                                  <span class="ms-ListItem-tertiaryText">${result.description}</span>
                                  <span class="ms-ListItem-metaText">10:15a</span>
                                   <div class="ms-ListItem-actions">
                                       <div class="ms-ListItem-action" targerUrl="${result.link}"><i class="ms-Icon ms-Icon--OpenInNewWindow">
                                       </i></div>
                                     </div>
                                </div>`;
                   });
               })
        .then(
          () => {
           setTimeout(() => {
             const action:HTMLCollectionOf<Element> = document.getElementsByClassName("ms-ListItem-action");
             for(let i=0;i<action.length;i++){
               action[i].addEventListener('click',(e)=>{
                 window.open((e.currentTarget as Element).getAttribute("TargerUrl"));
               });
             }
           },300);
            resolve(resultsHtml);
           }
        );
      }
      else{
        resultsHtml += "Please provide search query input in searchbox.....";
        resolve(resultsHtml);
      }
    });
  }


  protected get dataVersion(): Version {
  return Version.parse('1.0');
}

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
  return {
    pages: [
      {
        header: {
          description: strings.PropertyPaneDescription
        },
        groups: [
          {
            groupName: strings.BasicGroupName,
            groupFields: [
              PropertyPaneTextField('description', {
                label: strings.DescriptionFieldLabel
              })
            ]
          }
        ]
      }
    ]
  };
}
}
