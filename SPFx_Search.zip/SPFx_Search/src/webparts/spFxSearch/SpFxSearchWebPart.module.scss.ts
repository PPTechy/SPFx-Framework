/* tslint:disable */
require("./SpFxSearchWebPart.module.css");
const styles = {
  spFxSearch: 'spFxSearch_1708f820',
  container: 'container_1708f820',
  row: 'row_1708f820',
  column: 'column_1708f820',
  'ms-Grid': 'ms-Grid_1708f820',
  title: 'title_1708f820',
  subTitle: 'subTitle_1708f820',
  description: 'description_1708f820',
  button: 'button_1708f820',
  label: 'label_1708f820'
};

export default styles;
/* tslint:enable */