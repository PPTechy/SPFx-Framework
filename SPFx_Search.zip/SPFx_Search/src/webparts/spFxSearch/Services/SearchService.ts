'use strict';
import * as pnp from 'sp-pnp-js';
 
export interface ISearchResult {
    link : string;
    title : string;
    description : string;
    author:string;
}
 
export interface ISearchService{
    GetMockSearchResults(query:string) : Promise<ISearchResult[]>;
}

export class MockSearchService implements ISearchService
{
    public GetMockSearchResults(query:string) : Promise<ISearchResult[]>{
        return new Promise<ISearchResult[]>((resolve,reject) => {
          
      resolve([
                    {title:'This is test title 1',description:'Test Title 1 description',link:'https://globalsharepoint2020.sharepoint.com Jump ',author:'Global SharePoint1'},
                    {title:'This is test title 2',description:'Test Title 2 description',link:'https://globalsharepoint2020.sharepoint.comJump ',author:'Global SharePoint2'},
                    ]);
        });
    }
}
  
export class SearchService implements ISearchService
{
    public GetMockSearchResults(query:string) : Promise<ISearchResult[]>{
        const _results:ISearchResult[] = [];
  
        return new Promise<ISearchResult[]>((resolve,reject) => {
                pnp.sp.search({
                     Querytext:query,
                     RowLimit:20,
                     StartRow:0
                    })
                .then((results) => {
                   results.PrimarySearchResults.forEach((result)=>{
                    _results.push({
                        title:result.Title,
                        description:result.HitHighlightedSummary,
                        link:result.Path,
                        author:result.Author
                    });
                   });
                })
                .then(
                   () => { resolve(_results);}
                )
                .catch(
                    () => {reject(new Error("Error")); }
                );
                  
        });
    }
}