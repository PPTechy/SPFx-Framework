/* tslint:disable */
require("./SpcrudOperationUsingSpFxNoJavascriptFrameworkWebPart.module.css");
const styles = {
  spcrudOperationUsingSpFxNoJavascriptFramework: 'spcrudOperationUsingSpFxNoJavascriptFramework_147a045e',
  container: 'container_147a045e',
  row: 'row_147a045e',
  column: 'column_147a045e',
  'ms-Grid': 'ms-Grid_147a045e',
  title: 'title_147a045e',
  subTitle: 'subTitle_147a045e',
  description: 'description_147a045e',
  button: 'button_147a045e',
  label: 'label_147a045e'
};

export default styles;
/* tslint:enable */