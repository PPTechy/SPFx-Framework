export interface IListItem
 {  
    Title?: string;  
    Id: number;  
}  
//#SourceMappingURL=IListItem.d.ts.map