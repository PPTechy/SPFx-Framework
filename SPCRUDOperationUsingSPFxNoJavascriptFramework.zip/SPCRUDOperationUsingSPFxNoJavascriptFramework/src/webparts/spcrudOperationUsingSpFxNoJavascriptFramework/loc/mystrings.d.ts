declare interface ISpcrudOperationUsingSpFxNoJavascriptFrameworkWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string; 
  ListNameFieldLabel: string;

}

declare module 'SpcrudOperationUsingSpFxNoJavascriptFrameworkWebPartStrings'
 {
  const strings: ISpcrudOperationUsingSpFxNoJavascriptFrameworkWebPartStrings;
  export = strings;
}
