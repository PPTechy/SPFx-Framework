import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import './loc/css/MyAppStyle.css';
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Title: string;
}
export interface ISpcrudOperationUsingSpFxNoJavascriptFrameworkWebPartProps {
    description: string;
}
export default class SpcrudOperationUsingSpFxNoJavascriptFrameworkWebPart extends BaseClientSideWebPart<ISpcrudOperationUsingSpFxNoJavascriptFrameworkWebPartProps> {
    private listItemEntityTypeName;
    private Listname;
    private _getListData;
    private _renderListAsync;
    private _renderList;
    render(): void;
    private setButtonsEventHandlers;
    private getAllItemsFromList;
    private SaveItemToList;
    private UpdateItemClicked;
    private updateItemInList;
    private DeleteItemClicked;
    private deleteItemfromList;
    private getItemByIDFromList;
    private ClearMethodInForm;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SpcrudOperationUsingSpFxNoJavascriptFrameworkWebPart.d.ts.map