declare interface IHelloWorldApplicationCustomizerApplicationCustomizerStrings {
  Title: string;
}

declare module 'HelloWorldApplicationCustomizerApplicationCustomizerStrings' {
  const strings: IHelloWorldApplicationCustomizerApplicationCustomizerStrings;
  export = strings;
}
