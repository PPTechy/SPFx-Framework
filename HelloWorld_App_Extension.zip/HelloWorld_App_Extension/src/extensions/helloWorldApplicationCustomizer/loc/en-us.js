define([], function() {
  return {
    "Title": "HelloWorldApplicationCustomizerApplicationCustomizer"
  }
});