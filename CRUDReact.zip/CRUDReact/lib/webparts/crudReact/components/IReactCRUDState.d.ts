import { IListItem } from './IListItem';
export interface IReactCRUDState {
    status: string;
    items: IListItem[];
}
//# sourceMappingURL=IReactCRUDState.d.ts.map