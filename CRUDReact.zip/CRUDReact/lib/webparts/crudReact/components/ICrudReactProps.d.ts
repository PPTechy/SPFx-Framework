import { SPHttpClient } from '@microsoft/sp-http';
export interface ICrudReactProps {
    listName: string;
    spHttpClient: SPHttpClient;
    siteUrl: string;
}
//# sourceMappingURL=ICrudReactProps.d.ts.map