import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'CrudReactWebPartStrings';
import CrudReact from './components/CrudReact';
import { ICrudReactProps } from './components/ICrudReactProps';

export interface ICrudReactWebPartProps 
{
  description: string;
  listName: string;
}

export default class CrudReactWebPart extends BaseClientSideWebPart <ICrudReactWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ICrudReactProps> = React.createElement(
      CrudReact,
      {
        //description: this.properties.description
        listName: this.properties.listName,
        spHttpClient: this.context.spHttpClient,  
        siteUrl: this.context.pageContext.web.absoluteUrl 
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
            //description: strings.ListNameFieldLabel
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [                
                  PropertyPaneTextField('listName', {
                  //label: strings.DescriptionFieldLabel
                  label: strings.ListNameFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}

//54: PropertyPaneTextField('description', {