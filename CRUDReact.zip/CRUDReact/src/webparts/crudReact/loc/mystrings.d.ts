declare interface ICrudReactWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ListNameFieldLabel:string;
}

declare module 'CrudReactWebPartStrings' {
  const strings: ICrudReactWebPartStrings;
  export = strings;
}
