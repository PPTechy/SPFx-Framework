import { SPHttpClient } from '@microsoft/sp-http'; 

export interface ICrudReactProps
 {
   //description: string;
   listName: string;   
   spHttpClient: SPHttpClient;  
   siteUrl: string; 
  
}
