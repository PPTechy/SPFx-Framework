/* tslint:disable */
require("./CrudReact.module.css");
const styles = {
  crudReact: 'crudReact_c9014be6',
  container: 'container_c9014be6',
  row: 'row_c9014be6',
  column: 'column_c9014be6',
  'ms-Grid': 'ms-Grid_c9014be6',
  title: 'title_c9014be6',
  subTitle: 'subTitle_c9014be6',
  description: 'description_c9014be6',
  button: 'button_c9014be6',
  label: 'label_c9014be6'
};

export default styles;
/* tslint:enable */