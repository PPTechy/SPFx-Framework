import { IListItem } from './IListItem';  
  
export interface IReactCRUDState {  
  status: string;  
  items: IListItem[];  
}  