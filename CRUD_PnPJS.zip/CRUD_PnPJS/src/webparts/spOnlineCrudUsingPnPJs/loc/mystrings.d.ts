declare interface ISpOnlineCrudUsingPnPJsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpOnlineCrudUsingPnPJsWebPartStrings' {
  const strings: ISpOnlineCrudUsingPnPJsWebPartStrings;
  export = strings;
}
