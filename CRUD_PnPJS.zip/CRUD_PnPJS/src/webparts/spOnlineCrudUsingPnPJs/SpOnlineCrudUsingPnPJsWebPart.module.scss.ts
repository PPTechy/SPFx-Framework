/* tslint:disable */
require("./SpOnlineCrudUsingPnPJsWebPart.module.css");
const styles = {
  spOnlineCrudUsingPnPJs: 'spOnlineCrudUsingPnPJs_8ce8134d',
  container: 'container_8ce8134d',
  row: 'row_8ce8134d',
  column: 'column_8ce8134d',
  'ms-Grid': 'ms-Grid_8ce8134d',
  title: 'title_8ce8134d',
  subTitle: 'subTitle_8ce8134d',
  description: 'description_8ce8134d',
  button: 'button_8ce8134d',
  label: 'label_8ce8134d'
};

export default styles;
/* tslint:enable */