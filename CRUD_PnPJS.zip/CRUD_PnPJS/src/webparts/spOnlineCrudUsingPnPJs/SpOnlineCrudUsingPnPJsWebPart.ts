import pnp from 'sp-pnp-js';   
import { Version } from '@microsoft/sp-core-library';   
import {   
 BaseClientSideWebPart,   
  IPropertyPaneConfiguration,  
  PropertyPaneTextField   
  } from '@microsoft/sp-webpart-base';   
  import { escape } from '@microsoft/sp-lodash-subset';    
      
 import styles from './SpOnlineCrudUsingPnPJsWebPart.module.scss';    
 import * as strings from 'SpOnlineCrudUsingPnPJsWebPartStrings';    
  
    
 export interface ISpOnlineCrudUsingPnPJsWebPartProps {  
  description: string;  
}  
  
   export interface ISPList {    
    ID: string;    
    EmpName: string;    
    EmpDepartment: string;    
  }     
     
 export default class SpOnlineCrudUsingPnPJsWebPart extends BaseClientSideWebPart<ISpOnlineCrudUsingPnPJsWebPartProps>
  {    
        
     
 private AddEventListeners() : void{    
   
  document.getElementById('AddItemToSPList').addEventListener('click',()=>this.AddSPListItem());    
  document.getElementById('UpdateItemInSPList').addEventListener('click',()=>this.UpdateSPListItem());    
  document.getElementById('DeleteItemFromSPList').addEventListener('click',()=>this.DeleteSPListItem());    
 }    
     
  private _getSPItems(): Promise<ISPList[]> {    
  return pnp.sp.web.lists.getByTitle("Employee").items.get().then((response) => {    
        
     return response;    
   });    
          
 }    
     
  private getSPItems(): void {    
        
     this._getSPItems()    
       .then((response) => {    
         this._renderList(response);    
       });    
 }    
     
 private _renderList(items: ISPList[]): void {    
   let html: string = '<table class="TFtable" border=1 width=style="bordercollapse: collapse;">';    
   html += `<th></th><th>ID</th><th>Name</th><th>Department</th>`;    
   if (items.length>0)  
   {  
   items.forEach((item: ISPList) => {    
     html += `    
          <tr>   
          <td>  <input type="radio" id="empID" name="empID" value="${item.ID}"> <br> </td>   
          
         <td>${item.ID}</td>    
         <td>${item.EmpName}</td>    
         <td>${item.EmpDepartment}</td>    
         </tr>    
         `;     
   });    
  }  
  else    
  
  {  
    html +="No records...";  
  }  
   html += `</table>`;    
   const listContainer: Element = this.domElement.querySelector('#DivGetItems');    
   listContainer.innerHTML = html;    
 }         
     
     
   public render(): void {    
     this.domElement.innerHTML = `    
     <div class="parentContainer" style="background-color: white">    
    <div class="ms-Grid-row ms-bgColor-themeDark ms-fontColor-white ${styles.row}">    
       <div class="ms-Grid-col ms-u-lg   
   ms-u-xl8 ms-u-xlPush2 ms-u-lgPush1">   
     
           
       </div>    
    </div>    
    <div class="ms-Grid-row ms-bgColor-themeDark ms-fontColor-white ${styles.row}">    
       <div style="background-color:Black;color:white;text-align: center;font-weight: bold;font-size:   
   x;">Employee Details</div>    
           
    </div>    
    <div style="background-color: white" >    
       <form >    
          <br>    
          <div data-role="header">    
             <h3>Add item to SharePoint List</h3>    
          </div>    
           <div data-role="main" class="ui-content">    
             <div >    
                
               
               <input id="EmpName"  placeholder="EmpName"/>    
               <input id="EmpDepartment"  placeholder="EmpDepartment"/>    
               <button id="AddItemToSPList"  type="submit" >Add</button>    
               <button id="UpdateItemInSPList" type="submit" >Update</button>    
               <button id="DeleteItemFromSPList"  type="submit" >Delete</button>  
             </div>    
           </div>    
       </form>    
    </div>    
    <br>    
    <div style="background-color: white" id="DivGetItems" />    
      
    </div>   
    `;    

   
 this.getSPItems();    
 this.AddEventListeners();    
   }    
     
   AddSPListItem()    
   {      
       
        pnp.sp.web.lists.getByTitle('Employee').items.add({        
            EmpName : document.getElementById('EmpName')["value"],    
            EmpDepartment : document.getElementById('EmpDepartment')["value"]  
           
       });   
     
        alert("Record with Employee Name : "+ document.getElementById('Employee')["value"] + " Added !");    
          
   }    


UpdateSPListItem()    
{      
 var empID =  this.domElement.querySelector('input[name = "empID"]:checked')["value"];  
    pnp.sp.web.lists.getByTitle("Employee").items.getById(empID).update({    
     EmpName : document.getElementById('EmpName')["value"],    
     EmpDepartment : document.getElementById('EmpDepartment')["value"]  
       
  });    
 alert("Record with Employee ID : "+ empID + " Updated !");    
}    
    
DeleteSPListItem()    
{      
 var empID =  this.domElement.querySelector('input[name = "empID"]:checked')["value"];  
   
     pnp.sp.web.lists.getByTitle("Employee").items.getById(empID).delete();    
     alert("Record with Employee ID : "+ empID + " Deleted !");    
}   

     
   protected get dataVersion(): Version 
   {    
     return Version.parse('1.0');    
   }    
     
   protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {    
     return {    
       pages: [    
         {    
           header: {    
             description: strings.PropertyPaneDescription    
           },    
           groups: [    
             {    
               groupName: strings.BasicGroupName,    
               groupFields: [    
                 PropertyPaneTextField('description', {    
                   label: strings.DescriptionFieldLabel    
                 })    
               ]    
             }    
           ]    
         }    
       ]    
     };    
   }    
 }  