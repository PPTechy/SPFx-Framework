import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface ISpOnlineCrudUsingPnPJsWebPartProps {
    description: string;
}
export interface ISPList {
    ID: string;
    EmpName: string;
    EmpDepartment: string;
}
export default class SpOnlineCrudUsingPnPJsWebPart extends BaseClientSideWebPart<ISpOnlineCrudUsingPnPJsWebPartProps> {
    private AddEventListeners;
    private _getSPItems;
    private getSPItems;
    private _renderList;
    render(): void;
    AddSPListItem(): void;
    UpdateSPListItem(): void;
    DeleteSPListItem(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SpOnlineCrudUsingPnPJsWebPart.d.ts.map