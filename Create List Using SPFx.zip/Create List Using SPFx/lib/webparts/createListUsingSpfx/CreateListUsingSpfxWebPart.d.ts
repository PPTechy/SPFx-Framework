import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface ICreateListUsingSpfxWebPartProps {
    description: string;
}
export default class CreatePnPListWebPart extends BaseClientSideWebPart<ICreateListUsingSpfxWebPartProps> {
    render(): void;
    private CreateListInSPOUsinPnPSPFx;
    private AddEventListeners;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=CreateListUsingSpfxWebPart.d.ts.map