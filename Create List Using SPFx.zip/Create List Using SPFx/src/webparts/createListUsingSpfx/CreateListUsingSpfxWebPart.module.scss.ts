/* tslint:disable */
require("./CreateListUsingSpfxWebPart.module.css");
const styles = {
  createListUsingSpfx: 'createListUsingSpfx_1b44953f',
  container: 'container_1b44953f',
  row: 'row_1b44953f',
  column: 'column_1b44953f',
  'ms-Grid': 'ms-Grid_1b44953f',
  title: 'title_1b44953f',
  subTitle: 'subTitle_1b44953f',
  description: 'description_1b44953f',
  button: 'button_1b44953f',
  label: 'label_1b44953f'
};

export default styles;
/* tslint:enable */