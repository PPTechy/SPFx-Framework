/* tslint:disable */
require("./HeaderAndFooterAppExtensionApplicationCustomizer.module.css");
const styles = {
  appCustomHeaderFooter: 'appCustomHeaderFooter_631d6bb7',
  top: 'top_631d6bb7',
  bottom: 'bottom_631d6bb7'
};

export default styles;
/* tslint:enable */