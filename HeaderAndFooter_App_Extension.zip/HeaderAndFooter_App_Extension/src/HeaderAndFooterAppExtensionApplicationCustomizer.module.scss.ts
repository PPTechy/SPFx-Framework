/* tslint:disable */
require("./HeaderAndFooterAppExtensionApplicationCustomizer.module.css");
const styles = {
  appCustomHeaderFooter: 'appCustomHeaderFooter_d5a1b6a9',
  top: 'top_d5a1b6a9',
  bottom: 'bottom_d5a1b6a9'
};

export default styles;
/* tslint:enable */