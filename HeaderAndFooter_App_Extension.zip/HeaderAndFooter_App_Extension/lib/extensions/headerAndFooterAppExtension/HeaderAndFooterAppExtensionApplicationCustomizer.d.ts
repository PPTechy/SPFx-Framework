import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IHeaderAndFooterAppExtensionApplicationCustomizerProperties {
    Top: string;
    Bottom: string;
}
/** A Custom Action which can be run during execution of a Client Side Application */
export default class HeaderAndFooterAppExtensionApplicationCustomizer extends BaseApplicationCustomizer<IHeaderAndFooterAppExtensionApplicationCustomizerProperties> {
    private _topPlaceholderHeader;
    private _bottomPlaceholderFooter;
    onInit(): Promise<void>;
    private _renderPlaceHoldersHeaderandFooter;
    private _onDispose;
}
//# sourceMappingURL=HeaderAndFooterAppExtensionApplicationCustomizer.d.ts.map