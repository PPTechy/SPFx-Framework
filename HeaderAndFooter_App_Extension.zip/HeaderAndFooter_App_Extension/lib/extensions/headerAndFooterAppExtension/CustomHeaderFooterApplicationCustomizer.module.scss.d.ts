declare const styles: {
    app: string;
    top: string;
    bottom: string;
};
export default styles;
//# sourceMappingURL=CustomHeaderFooterApplicationCustomizer.module.scss.d.ts.map